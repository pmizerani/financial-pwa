# 📈 Calculadora Melhorada - Financial PWA

## ✨ Novas Funcionalidades

### 🎯 **Escolha entre Pré e Pós-Fixado**

Agora você pode configurar cada investimento como **pré-fixado** ou **pós-fixado**!

---

## 🔄 Investimentos Configuráveis

### **1. CDB**
#### Pós-fixado (% do CDI)
- Exemplo: 100% do CDI
- Rendimento acompanha o CDI
- Mais comum no mercado

#### Pré-fixado (% a.a.)
- Exemplo: 12,00% ao ano
- Taxa fixa conhecida na contratação
- Rendimento garantido

---

### **2. LCI/LCA**
#### Pós-fixado (% do CDI)
- Exemplo: 85% do CDI
- Isento de IR
- Rendimento acompanha o CDI

#### Pré-fixado (% a.a.)
- Exemplo: 10,00% ao ano
- Taxa fixa conhecida
- Isento de IR

---

### **3. Tesouro Selic**
- **Sempre pós-fixado** (acompanha a Selic)
- Configurável: % da Selic (geralmente 100%)
- Taxa de custódia: 0,2% a.a.
- IR regressivo aplicado

---

### **4. Poupança**
- **Rendimento mensal fixo**
- Calculado automaticamente pela regra:
  - Se Selic > 8,5% → 0,5% a.m.
  - Se Selic ≤ 8,5% → 70% da Selic (convertido mensal)
- Isento de IR

---

## 🎨 Visual Melhorado

### **Cards por Investimento**
Cada investimento agora tem seu próprio card com:
- ✅ Nome destacado
- ✅ Radio buttons para escolher tipo (pré/pós)
- ✅ Campo de entrada específico por tipo
- ✅ Labels explicativos

### **Layout Responsivo**
- Desktop: 4 cards lado a lado
- Tablet: 2 cards por linha
- Mobile: 1 card por linha

### **Grid Completo**
A seção de rentabilidades ocupa toda a largura (`grid-column: 1 / -1`)

---

## 💡 Como Usar

### **1. Abrir Calculadora**
```
Menu → 📈 Calculadora
```

### **2. Configurar Dados da Simulação**
- Investimento inicial
- Aportes mensais
- Período em meses

### **3. Taxas Carregam Automaticamente**
- Selic, CDI e IPCA via API do Banco Central
- Poupança calculada pela regra oficial

### **4. Escolher Tipo de Cada Investimento**

#### Para CDB:
- Clicar em **"📈 Pós-fixado"** ou **"💰 Pré-fixado"**
- Se pós: digitar % do CDI (ex: 100,00)
- Se pré: digitar % ao ano (ex: 12,00)

#### Para LCI/LCA:
- Clicar em **"📈 Pós-fixado"** ou **"💰 Pré-fixado"**
- Se pós: digitar % do CDI (ex: 85,00)
- Se pré: digitar % ao ano (ex: 10,00)

#### Tesouro e Poupança:
- Já vêm configurados corretamente
- Apenas ajustar se necessário

### **5. Calcular**
```
📈 Calcular Simulação
```

---

## 📊 Resultados Aprimorados

### **Labels Descritivos**
Agora os resultados mostram:
- ✅ "CDB 100% CDI" (pós-fixado)
- ✅ "CDB 12.00% a.a." (pré-fixado)
- ✅ "LCI/LCA 85% CDI" (pós-fixado)
- ✅ "LCI/LCA 10.00% a.a." (pré-fixado)
- ✅ "Tesouro Selic 100%"
- ✅ "Poupança"

### **Ranking Dinâmico**
- 🏆 Melhor opção
- 2º lugar
- 3º lugar
- 4º lugar

### **Detalhamento Completo**
Para cada investimento:
- Total investido
- Rendimento bruto
- IR (se aplicável)
- Taxa de custódia (Tesouro)
- **Rendimento líquido**
- **Rentabilidade %**

---

## 🧮 Cálculos

### **Pós-fixado**
```javascript
// CDB 100% CDI (CDI = 10,65%)
taxa_anual = 10,65% × 1,00 = 10,65%
taxa_mensal = (1 + 0,1065)^(1/12) - 1
```

### **Pré-fixado**
```javascript
// CDB 12% a.a.
taxa_anual = 12,00%
taxa_mensal = (1 + 0,12)^(1/12) - 1
```

### **IR Regressivo (CDB e Tesouro)**
| Período | Alíquota |
|---------|----------|
| Até 6 meses | 22,5% |
| 6 a 12 meses | 20,0% |
| 12 a 24 meses | 17,5% |
| Acima de 24 meses | 15,0% |

### **Isentos de IR**
- LCI/LCA (sempre)
- Poupança (sempre)

---

## 🎯 Exemplos Práticos

### **Cenário 1: Investimento Conservador**
```
Inicial: R$ 10.000,00
Aportes: R$ 1.000,00/mês
Período: 12 meses

CDB: Pós 100% CDI → R$ 23.226,45
LCI: Pós 85% CDI → R$ 23.107,82
Tesouro: 100% Selic → R$ 23.214,32
Poupança: 0,5% a.m. → R$ 22.768,45
```

### **Cenário 2: Investimento Agressivo**
```
Inicial: R$ 10.000,00
Aportes: R$ 1.000,00/mês
Período: 24 meses

CDB: Pré 13% a.a. → R$ 38.894,21
LCI: Pré 11% a.a. → R$ 38.234,56 (sem IR!)
Tesouro: 100% Selic → R$ 37.982,11
Poupança: 0,5% a.m. → R$ 37.105,22
```

---

## 🔧 Melhorias Técnicas

### **JavaScript**
- ✅ Função `toggleCalcTipo(invest)` para alternar campos
- ✅ Detecção do tipo selecionado antes de calcular
- ✅ Labels dinâmicos nos resultados
- ✅ Formatação correta de percentuais

### **CSS**
- ✅ Classe `.calc-invest-card` para cards
- ✅ Grid responsivo com `auto-fit`
- ✅ Altura fixa para alinhamento visual

### **HTML**
- ✅ Radio buttons estilizados (reutiliza CSS existente)
- ✅ IDs únicos para cada campo
- ✅ Grid full-width para seção de rentabilidades

---

## 📱 Compatibilidade

- ✅ Desktop (4 cards lado a lado)
- ✅ Tablet (2 cards por linha)
- ✅ Mobile (1 card por linha)
- ✅ PWA instalado
- ✅ Offline (após primeira carga)

---

## 🎨 Design System

### **Cores dos Cards**
```css
background: #0f172a;
border: 1px solid #334155;
border-radius: 8px;
padding: 16px;
```

### **Radio Buttons**
- Reutiliza estilo existente da página de investimentos
- Azul quando selecionado (#3b82f6)
- Cinza quando não selecionado

### **Inputs**
- Labels pequenos (13px)
- Inputs com máscara de percentual
- Focus state azul

---

## 🚀 Como Testar

### **1. Abrir Calculadora**
```
http://localhost:8080/investimentos.html
Menu → 📈 Calculadora
```

### **2. Testar CDB Pós-fixado**
- Selecionar "📈 Pós-fixado"
- Digitar: 110,00 (110% do CDI)
- Calcular

### **3. Testar CDB Pré-fixado**
- Selecionar "💰 Pré-fixado"
- Digitar: 13,50 (13,5% a.a.)
- Calcular

### **4. Comparar Resultados**
- Ver qual rende mais
- Observar diferença de IR
- Checar rentabilidade %

---

## 📝 Changelog

### Added
- ✅ Escolha entre pré e pós-fixado para CDB
- ✅ Escolha entre pré e pós-fixado para LCI/LCA
- ✅ Cards individuais por investimento
- ✅ Labels descritivos nos resultados
- ✅ Função `toggleCalcTipo()`

### Changed
- ✅ Layout de rentabilidades (cards ao invés de lista)
- ✅ Grid full-width para rentabilidades
- ✅ Nomes dos investimentos nos resultados

### Fixed
- ✅ Formatação de percentuais nos labels
- ✅ Responsividade em mobile

---

**Versão:** 2.1  
**Data:** Abril 2026  
**Status:** ✅ Testado e funcionando
